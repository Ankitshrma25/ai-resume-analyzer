import { NextRequest, NextResponse } from 'next/server';
import dbConnect from '@/lib/db';
import Request from '@/models/Request';
import Item from '@/models/Item';

export async function GET(request: NextRequest) {
  try {
    await dbConnect();

    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const section = searchParams.get('section');
    const priority = searchParams.get('priority');
    const location = searchParams.get('location');

    let query: any = { isActive: true };

    if (status) query.status = status;
    if (section) query.requesterSection = section;
    if (priority) query.priority = priority;
    if (location) query.currentLocation = location;

    const requests = await Request.find(query)
      .populate('requesterId', 'name username rank')
      .populate('approvedBy', 'name username')
      .populate('allocatedBy', 'name username')
      .sort({ createdAt: -1 });

    return NextResponse.json({ requests });

  } catch (error) {
    console.error('Get requests error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    await dbConnect();

    const {
      requesterId,
      requesterName,
      requesterSection,
      requesterRank,
      items,
      priority,
      notes,
      sourceLocation,
    } = await request.json();

    // Validate required fields
    if (!requesterId || !requesterName || !requesterSection || !items || items.length === 0) {
      return NextResponse.json(
        { error: 'All required fields must be provided' },
        { status: 400 }
      );
    }

    // Validate items and calculate total cost
    let totalCost = 0;
    const validatedItems = [];

    for (const item of items) {
      const itemDoc = await Item.findById(item.itemId);
      if (!itemDoc) {
        return NextResponse.json(
          { error: `Item with ID ${item.itemId} not found` },
          { status: 404 }
        );
      }

      if (item.quantity <= 0) {
        return NextResponse.json(
          { error: 'Quantity must be greater than 0' },
          { status: 400 }
        );
      }

      // Check if requested quantity is available at source location
      if (itemDoc.location !== sourceLocation) {
        return NextResponse.json(
          { error: `Item ${itemDoc.itemName} is not available at ${sourceLocation}` },
          { status: 400 }
        );
      }

      // Check if requested quantity is available
      if (itemDoc.stockLevel < item.quantity) {
        return NextResponse.json(
          { error: `Insufficient stock for ${itemDoc.itemName}. Available: ${itemDoc.stockLevel}` },
          { status: 400 }
        );
      }

      const estimatedCost = itemDoc.cost * item.quantity;
      totalCost += estimatedCost;

      validatedItems.push({
        itemId: item.itemId,
        itemName: itemDoc.itemName,
        serialNumber: itemDoc.serialNumber,
        category: itemDoc.category,
        quantity: item.quantity,
        unit: itemDoc.unit,
        purpose: item.purpose,
        estimatedCost,
      });
    }

    const newRequest = new Request({
      requesterId,
      requesterName,
      requesterSection,
      requesterRank,
      items: validatedItems,
      priority: priority || 'medium',
      notes: notes || '',
      totalCost,
      sourceLocation: sourceLocation || 'localStore',
      currentLocation: sourceLocation || 'localStore',
    });

    await newRequest.save();

    return NextResponse.json({
      message: 'Request created successfully',
      request: newRequest,
    }, { status: 201 });

  } catch (error) {
    console.error('Create request error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
} 