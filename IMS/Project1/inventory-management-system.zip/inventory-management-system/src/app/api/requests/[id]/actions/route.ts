import { NextRequest, NextResponse } from 'next/server';
import dbConnect from '@/lib/db';
import Request from '@/models/Request';
import Item from '@/models/Item';

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await dbConnect();

    const { action, performedBy, notes, allocatedFrom } = await request.json();

    if (!action || !performedBy) {
      return NextResponse.json(
        { error: 'Action and performedBy are required' },
        { status: 400 }
      );
    }

    const requestDoc = await Request.findById(params.id);
    if (!requestDoc) {
      return NextResponse.json(
        { error: 'Request not found' },
        { status: 404 }
      );
    }

    switch (action) {
      case 'forwardToWSG':
        await requestDoc.forwardToWSG(performedBy);
        break;

      case 'forwardToCOD':
        await requestDoc.forwardToCOD(performedBy);
        break;

      case 'allocate':
        if (!allocatedFrom) {
          return NextResponse.json(
            { error: 'allocatedFrom is required for allocation' },
            { status: 400 }
          );
        }
        
        // Check if items are available for allocation
        for (const item of requestDoc.items) {
          const itemDoc = await Item.findById(item.itemId);
          if (!itemDoc) {
            return NextResponse.json(
              { error: `Item ${item.itemName} not found` },
              { status: 404 }
            );
          }
          
          if (itemDoc.location !== allocatedFrom) {
            return NextResponse.json(
              { error: `Item ${item.itemName} is not available at ${allocatedFrom}` },
              { status: 400 }
            );
          }
          
          if (itemDoc.stockLevel < item.quantity) {
            return NextResponse.json(
              { error: `Insufficient stock for ${item.itemName}. Available: ${itemDoc.stockLevel}` },
              { status: 400 }
            );
          }
        }

        // Allocate items and update stock
        await requestDoc.allocateItems(performedBy, allocatedFrom);
        
        // Update item stock levels
        for (const item of requestDoc.items) {
          const itemDoc = await Item.findById(item.itemId);
          if (itemDoc) {
            await itemDoc.updateStock(item.quantity, 'issued');
            await itemDoc.addTransaction({
              type: 'issued',
              quantity: item.quantity,
              reference: requestDoc.requestNumber,
              notes: `Allocated for request ${requestDoc.requestNumber}`,
              performedBy,
            });
          }
        }
        break;

      case 'approve':
        requestDoc.status = 'approved';
        requestDoc.approvedBy = new (require('mongoose').Types.ObjectId)(performedBy);
        requestDoc.approvedAt = new Date();
        if (notes) {
          requestDoc.notes += `\n${notes}`;
        }
        await requestDoc.save();
        break;

      case 'reject':
        requestDoc.status = 'rejected';
        requestDoc.rejectionReason = notes || 'Request rejected';
        if (notes) {
          requestDoc.notes += `\nRejection reason: ${notes}`;
        }
        await requestDoc.save();
        break;

      case 'complete':
        requestDoc.status = 'completed';
        requestDoc.actualDeliveryDate = new Date();
        if (notes) {
          requestDoc.notes += `\n${notes}`;
        }
        await requestDoc.save();
        break;

      default:
        return NextResponse.json(
          { error: 'Invalid action' },
          { status: 400 }
        );
    }

    return NextResponse.json({
      message: `Request ${action} successful`,
      request: requestDoc,
    });

  } catch (error) {
    console.error('Request action error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
} 