(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_f79370a8._.js",
  "static/chunks/node_modules_recharts_es6_46463bd4._.js",
  "static/chunks/node_modules_9e383b9d._.js"
],
    source: "dynamic"
});
