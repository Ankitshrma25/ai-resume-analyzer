(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_(Dashboard)_manage-inventory_page_tsx_5839a310._.js"
],
    source: "dynamic"
});
