(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_53792b9e._.js",
  "static/chunks/8484d_tailwind-merge_dist_bundle-mjs_mjs_4d8e7d9e._.js",
  "static/chunks/60489_axios_lib_6cb46e6d._.js",
  "static/chunks/3fcb3_zod_v3_10cbb2c5._.js",
  "static/chunks/node_modules__pnpm_9b96d56d._.js"
],
    source: "dynamic"
});
