__turbopack_load_page_chunks__("/_app", [
  "static/chunks/[root-of-the-server]__6c035462._.js",
  "static/chunks/a14e7_react-dom_638ad3bb._.js",
  "static/chunks/node_modules__pnpm_51c25b77._.js",
  "static/chunks/[root-of-the-server]__49fd8634._.js",
  "static/chunks/pages__app_5771e187._.js",
  "static/chunks/pages__app_6a2a71b1._.js"
])
