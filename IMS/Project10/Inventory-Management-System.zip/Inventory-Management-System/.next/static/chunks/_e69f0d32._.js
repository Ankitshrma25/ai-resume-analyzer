(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_d5ccf037._.js",
  "static/chunks/9bf22_next_dist_compiled_7c0b275a._.js",
  "static/chunks/9bf22_next_dist_client_3d678745._.js",
  "static/chunks/9bf22_next_dist_11d686e8._.js",
  "static/chunks/61dca_@swc_helpers_cjs_e27e0aca._.js"
],
    source: "entry"
});
