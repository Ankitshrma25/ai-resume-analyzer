(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_(Dashboard)_settings_page_tsx_7c1382c5._.js"
],
    source: "dynamic"
});
